<?php

class StoreCredential extends Eloquent {
	
}