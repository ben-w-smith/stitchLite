<?php

class Store extends Eloquent {
	
}