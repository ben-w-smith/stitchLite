<?php

class Product extends Eloquent {
	
}