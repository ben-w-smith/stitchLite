@extends('layout.main')

@section('content')
	<pre>{{ var_dump($var) }}</pre>
@stop